# CoffeeHub 1.5.0 Para Windows - PowerShell Version
# Requer execução como Administrador

param([switch]$Force)

# Verificar e solicitar privilégios de administrador
if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "Solicitando privilégios de administrador..." -ForegroundColor Yellow
    $currentDir = Get-Location
    Start-Process PowerShell -Verb RunAs -ArgumentList ("-NoProfile -ExecutionPolicy Bypass -Command `"Set-Location '$currentDir'; & '$($MyInvocation.MyCommand.Path)'`"")
    exit
}

# Configurar codificação UTF-8
$PSDefaultParameterValues['*:Encoding'] = 'utf8'
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::InputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
chcp 65001 > $null

# Configurações
$Version = "1.5.0"
$VersionBin = "1-5-0"
$CurrentDir = Get-Location
$InstallPath = Join-Path $CurrentDir "..\CoffeeHub"
$BinPath = $CurrentDir

# Função para exibir banner
function Show-Banner {
    Write-Host ""
    Write-Host "  ____       __ __           _   _       _" -ForegroundColor Green
    Write-Host " / ___\___  / _/ _\ ___  ___| | | |_   _| |__" -ForegroundColor Green
    Write-Host "| |   / _ \| |_| |_ / _ \/ _ \ |_| | | | | '_ \" -ForegroundColor Green
    Write-Host "| |__| (_) |  _  _|  __/  __/  _  | |_| | |_) |" -ForegroundColor Green
    Write-Host " \____\___/|_| |_|  \___|\__|_| |_|\__,_|_.__/" -ForegroundColor Green
    Write-Host "                                          $Version" -ForegroundColor Cyan
    Write-Host ""
}

# Verificar Node.js
function Test-NodeJS {
    try {
        $nodeVersion = & node -v 2>$null
        if ($LASTEXITCODE -eq 0) {
            Write-Host "Node.js encontrado: $nodeVersion" -ForegroundColor Green
            return $true
        }
    }
    catch { return $false }
    return $false
}

# Obter chave de ativação
function Get-ActivationKey {
    Write-Host "=== CHAVE DE ATIVAÇÃO ===" -ForegroundColor Cyan
    
    do {
        $hasKey = Read-Host "Você possui alguma chave de ativação CoffeeHub? (s/n)"
    } while ($hasKey -notin @('s', 'n', 'S', 'N'))
    
    if ($hasKey -in @('s', 'S')) {
        do {
            $key = Read-Host "Qual sua chave CoffeeHub?"
            if (![string]::IsNullOrWhiteSpace($key)) {
                $confirmation = Read-Host "A chave '$key' está correta? (s/n)"
                if ($confirmation -in @('s', 'S')) {
                    return $key
                }
            }
        } while ($true)
    }
    return $null
}

# Extrair arquivo ZIP
function Expand-CoffeeHubArchive {
    param([string]$ZipPath, [string]$DestinationPath)
    
    try {
        Write-Host "Extraindo arquivo de instalação..." -ForegroundColor Yellow
        
        if (-not (Test-Path $ZipPath)) {
            Write-Host "ERRO: Arquivo ZIP não encontrado." -ForegroundColor Red
            return $false
        }
        
        if (-not (Test-Path $DestinationPath)) {
            New-Item -ItemType Directory -Path $DestinationPath -Force | Out-Null
        }
        
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $zip = [System.IO.Compression.ZipFile]::OpenRead($ZipPath)
        
        foreach ($entry in $zip.Entries) {
            $entryTargetPath = Join-Path $DestinationPath $entry.FullName
            $entryDir = Split-Path $entryTargetPath -Parent
            
            if (-not (Test-Path $entryDir)) {
                New-Item -ItemType Directory -Path $entryDir -Force | Out-Null
            }
            
            if (-not $entry.FullName.EndsWith('/')) {
                [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $entryTargetPath, $true)
            }
        }
        $zip.Dispose()
        Remove-Item $ZipPath -Force
        
        # Criar pastas necessárias após extração
        @("CHECKER", "GERADOR", "LOGS", "MINERADOS") | ForEach-Object {
            $folderPath = Join-Path $DestinationPath $_
            if (-not (Test-Path $folderPath)) {
                New-Item -ItemType Directory -Path $folderPath -Force | Out-Null
            }
        }
        
        Write-Host "Extração concluída." -ForegroundColor Green
        return $true
    }
    catch {
        Write-Host "Erro ao extrair: $($_.Exception.Message)" -ForegroundColor Red
        if ($zip) { $zip.Dispose() }
        return $false
    }
}

# Criar arquivos de inicialização
function New-Scripts {
    param([string]$InstallDirectory, [string]$Key = $null)
    
    # start.bat
    $startScript = @"
@echo off
chcp 65001
node coffee-loader/client
pause
"@
    $startScript | Out-File -FilePath (Join-Path $InstallDirectory "start.bat") -Encoding ASCII -Force
    
    # LEIA_ME.txt
    $readmeContent = @"
Execute o comando "npm i" nessa pasta caso não seja possivel reparar via BIOS
Voce pode deletar este aviso
"@
    $readmeContent | Out-File -FilePath (Join-Path $InstallDirectory "LEIA_ME.txt") -Encoding UTF8 -Force
    
    # KEY.txt
    if ($Key) {
        $Key | Out-File -FilePath (Join-Path $InstallDirectory "KEY.txt") -Encoding UTF8 -Force
    }
}

# Função principal
function Start-CoffeeHubInstaller {
    Show-Banner
    
    if (-not (Test-NodeJS)) {
        Write-Host "ERRO: Node.js não encontrado." -ForegroundColor Red
        Write-Host "Instale Node.js LTS de https://nodejs.org" -ForegroundColor Yellow
        Read-Host "Pressione Enter para sair"
        exit 1
    }
    
    $zipFile = Join-Path $BinPath "$VersionBin.zip"
    Write-Host "Procurando arquivo: $zipFile" -ForegroundColor Gray
    if (-not (Test-Path $zipFile)) {
        Write-Host "ERRO: Arquivo '$VersionBin.zip' não encontrado em '$BinPath'." -ForegroundColor Red
        Write-Host "Diretório atual: $(Get-Location)" -ForegroundColor Gray
        Write-Host "Arquivos disponíveis:" -ForegroundColor Yellow
        Get-ChildItem $BinPath -Filter "*.zip" | ForEach-Object { Write-Host "  - $($_.Name)" -ForegroundColor Gray }
        Read-Host "Pressione Enter para sair"
        exit 1
    }
    
    $activationKey = Get-ActivationKey
    
    Write-Host "=== INSTALANDO ===" -ForegroundColor Cyan
    
    if (-not (Test-Path $InstallPath)) {
        New-Item -ItemType Directory -Path $InstallPath -Force | Out-Null
    }
    
    if (-not (Expand-CoffeeHubArchive -ZipPath $zipFile -DestinationPath $InstallPath)) {
        Read-Host "Pressione Enter para sair"
        exit 1
    }
    
    New-Scripts -InstallDirectory $InstallPath -Key $activationKey
    
    Write-Host ""
    Write-Host "CoffeeHub instalado com sucesso!" -ForegroundColor Green
    Write-Host "Execute: start.bat" -ForegroundColor Yellow
    Write-Host "Local: $InstallPath" -ForegroundColor Gray
    Write-Host ""
}

# Executar
try {
    Start-CoffeeHubInstaller
}
catch {
    Write-Host "Erro: $($_.Exception.Message)" -ForegroundColor Red
}
finally {
    Read-Host "Pressione Enter para sair"
}