#!/bin/sh
# CoffeeHub 1.3.0 For Linux/Android

VER="1.3.0"
VER_BIN="1-3-0"

RESET="\033[0m"
GREEN="\033[32m"
YELLOW="\033[33m"
BOLD_CYAN="\033[1;36m"

echo "${BOLD_CYAN}
  ____       __  __           _   _       _
 / ___|___  / _|/ _| ___  ___| | | |_   _| |__
| |   / _ \\| |_| |_ / _ \\/ _ \\ |_| | | | | '_ \\
| |__| (_) |  _|  _|  __/  __/  _  | |_| | |_) |
 \\____\\___/|_| |_|  \\___|\\___|_| |_|\\__,_|_.__/
                                         ${VER}
${RESET}"

if ! command -v unzip >/dev/null 2>&1; then
    echo "${YELLOW}Extrator para o Coffeehub não encontrado, instalando...${RESET}"
    apt install unzip -y >/dev/null 2>&1
fi

if [ -d "./bin" ]; then
    echo "${GREEN}Binários para o CoffeeHub encontrados.${RESET}"

    if [ -f "./bin/${VER_BIN}.zip" ]; then
        file_type=$(file -b "./bin/${VER_BIN}.zip")

        if echo "$file_type" | grep -q "Zip archive data"; then
            unzip "./bin/${VER_BIN}.zip" -d "./bin/" >/dev/null 2>&1

            rm "./bin/${VER_BIN}.zip"
            echo "${GREEN}Setup inicial CoffeeHub concluído, instalando....${RESET}"

            mkdir -p ../CoffeeHub

            mv ./bin/* ../CoffeeHub/

            cd ../CoffeeHub || exit

            echo "${GREEN}Concluído, prosseguindo para os próximos passos..."
            echo "${YELLOW}Instalando dependências do CoffeeHub... (Pode demorar um pouco)${RESET}"
            npm install --no-bin-links >/dev/null 2>&1
            echo "${GREEN}Dependências do CoffeeHub instaladas com sucesso.${RESET}"

            while true; do
                printf "Você possui alguma chave de ativação CoffeeHub [s/n]: "
                read -r resposta

                case "$resposta" in
                    [sSyY])
                        while true; do
                            printf "Qual sua chave CoffeeHub ?: "
                            read -r chave
                            printf "A chave '%s' está correta? [s/n]: " "$chave"
                            read -r confirmacao
                            if [ "$confirmacao" = "s" ] || [ "$confirmacao" = "S" ] || [ "$confirmacao" = "y" ] || [ "$confirmacao" = "Y" ]; then
                                echo "$chave" > KEY.txt
                                echo "${GREEN}Chave salva com sucesso, estamos terminando a instalação...${RESET}"
                                break 2
                            else
                                printf "Digite novamente a sua chave: "
                            fi
                        done
                        ;;
                    [nN])
                        echo "${GREEN}Estamos concluindo a instalação...${RESET}"
                        break
                        ;;
                    *)
                        echo "${YELLOW}Resposta inválida. Digite 's' para sim ou 'n' para não.${RESET}"
                        ;;
                esac
            done


            cat > coffeehub <<EOF
#!/bin/sh
cd ../CoffeeHub || exit
if [ \$# -eq 0 ]; then
    node .
else
    node . "\$@"
fi
EOF

            echo "${RESET}
============================

CoffeeHub instalado com sucesso
Faça um bom uso de nosso serviço.

Para executar digite: sh coffeehub

============================
${RESET}"

        else
            echo "${RED}O arquivo do CoffeeHub está inválido, não será possível continuar.${RESET}"
        fi
    else
        echo "${RED}Binário de instalação não encontrado, não será possível continuar."
    fi
else
    echo "${RED}Binários não encontrados, abortando...${RESET}"
fi